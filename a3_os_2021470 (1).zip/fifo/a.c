#include<stdio.h>
#include<string.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<unistd.h>
#include<time.h>
#include<stdlib.h>
#include<sys/un.h>

int main(){
    char stringarray[50][7] = {{}}; 
  char arara[7];
    int i=0,j=0,asd;
    while(i<50) {
        while(j<5){
            stringarray[i][j] = rand() % 26 + 65;
          j++;
        }     
        stringarray[i][5]=i+1;
      i++;
    }
	char stringarrays[50][7]={{}};
	char * same= "f1";
	char * same1 = "f2";
  mkfifos(same,0666);
	mkfifo(same1,0666);
	int ci = 0,mi = 0;
    int msi=0;
  int tt=0,kk=0;
  while(tt<50) {
        while(rr<5){
            stringarrays[tt][rr] = rand() % 26 + 65;
          rr++;
        }     
        stringarrays[tt][5]=i+1;
      tt++;
    }
    while (1){
		
		if(mi >=50){
			break;
		}
        while(ci<mi+5){
			asd = open(same,O_WRONLY);
           int  reeq = write(asd, stringarray[ci], strlen(stringarray[ci]) + 1);
		   close(asd);
		   usleep(1); 
            if (reeq == -1){
                perror("Write Error");
                exit(1);}
          ci++;
        }
        mi = ci;
		asd = open(same1,O_RDONLY);
		int reeq = read(asd, arara, sizeof(arara));
		close(asd);
      
        if (reeq == -1)
        {
            perror("");
            exit(EXIT_FAILURE);
        }
        arara[sizeof(arara) - 1] = 0;
        printf("index sent is  %s\n", arara);
		
    }


}














void echo(char *ser,char cpyarr[])
{   char *str;
    str=strtok(ser," ");
    if(strcmp(ser,"-e")==0)
    {
        if(str!=NULL)
        {
            printf("%s",str);
        }
        else{
            printf("\n");
        }
    }
    else if(strcmp(ser,"-n")==0)
    {
        if(str!=NULL)
        {
            printf("%s\n",str);
        }
        else{
            printf("\n");
        }
    }
    else if(ser==NULL)
    {
        printf("\n");
    }
    else{
        if(str!=NULL)
        {
            printf("%s",ser);
        }
        else{
            printf("%s",ser);
        }
        
    }
}
void pwd(char *ser)
{   char w[100];
  if(ser==NULL)
    {
    printf("%s",getcwd(w,sizeof(w)));}
    else if(strcmp(ser,"-L"))
    {
        printf("%s",getcwd(w,sizeof(w)));
    }
    else if(strcmp(ser,"-P"))
    {
        printf("%s",getcwd(w,sizeof(w)));
    }
    else{
        printf("command not found");
    }
}
void cd(char *ser)
{
    if(strlen(ser)==0)
    {
        chdir("/home");
    }
    else if(strcmp(ser,"..")==0)
    {   
        chdir("..");
    }
    else if(ser=='~')
    {
        chdir("/home");
    }
    else{
        if(chdir(ser)!=0)
        {
            exit(EXIT_FAILURE);
        }

    }
}
void echo(char *ser,char cpyarr[])
{   char *str;
    str=strtok(ser," ");
    if(strcmp(ser,"-e")==0)
    {
        if(str!=NULL)
        {
            printf("%s",str);
        }
        else{
            printf("\n");
        }
    }
    else if(strcmp(ser,"-n")==0)
    {
        if(str!=NULL)
        {
            printf("%s\n",str);
        }
        else{
            printf("\n");
        }
    }
    else if(ser==NULL)
    {
        printf("\n");
    }
    else{
        if(str!=NULL)
        {
            printf("%s",ser);
        }
        else{
            printf("%s",ser);
        }
        
    }
}