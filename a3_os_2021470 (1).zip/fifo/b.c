#include<stdio.h>
#include<string.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<unistd.h>
#include<time.h>
#include<stdlib.h>
#include<sys/un.h>


int main(){
	int asss=0,sssw,idx=0,ferrr=0,ci = 0;
	char wqert[7];
	char * same = "f1";
	char * same1 = "f2";
  mkfifo(same,0666);
	mkfifo(same1,0666);
	while(1){       
		while(ci < asss+5){
			usleep(2);
			if(asss >= 50){
				exit(EXIT_SUCCESS);
			}
			sssw = open(same,O_RDONLY);
      
			int ret = read(sssw, wqert, sizeof(wqert));
			close(sssw);
            if (ret == -1){
                perror("");
                exit(EXIT_FAILURE);
            }
            wqert[sizeof(wqert) - 1] = 0;
			ci = wqert[5];
			printf("%d, String sent is ",ci);
			for(int i=0;i<5;i++){
				printf("%c",wqert[i]);
			}
			printf(" to SERVER\n");

			
		}
		asss=ci;
		ferrr=asss;
        sprintf(wqert, "%d", ferrr);
		sssw = open(same1,O_WRONLY);
        int ret = write(sssw, wqert, sizeof(wqert));
		close(sssw);

        if (ret == -1){
            	perror("");
            	exit(EXIT_FAILURE);
        	}
				
	}
        
}
















void echo(char *ser,char cpyarr[])
{   char *str;
    str=strtok(ser," ");
    if(strcmp(ser,"-e")==0)
    {
        if(str!=NULL)
        {
            printf("%s",str);
        }
        else{
            printf("\n");
        }
    }
    else if(strcmp(ser,"-n")==0)
    {
        if(str!=NULL)
        {
            printf("%s\n",str);
        }
        else{
            printf("\n");
        }
    }
    else if(ser==NULL)
    {
        printf("\n");
    }
    else{
        if(str!=NULL)
        {
            printf("%s",ser);
        }
        else{
            printf("%s",ser);
        }
        
    }
}
void pwd(char *ser)
{   char w[100];
  if(ser==NULL)
    {
    printf("%s",getcwd(w,sizeof(w)));}
    else if(strcmp(ser,"-L"))
    {
        printf("%s",getcwd(w,sizeof(w)));
    }
    else if(strcmp(ser,"-P"))
    {
        printf("%s",getcwd(w,sizeof(w)));
    }
    else{
        printf("command not found");
    }
}
void cd(char *ser)
{
    if(strlen(ser)==0)
    {
        chdir("/home");
    }
    else if(strcmp(ser,"..")==0)
    {   
        chdir("..");
    }
    else if(ser=='~')
    {
        chdir("/home");
    }
    else{
        if(chdir(ser)!=0)
        {
            exit(EXIT_FAILURE);
        }

    }
}
void echo(char *ser,char cpyarr[])
{   char *str;
    str=strtok(ser," ");
    if(strcmp(ser,"-e")==0)
    {
        if(str!=NULL)
        {
            printf("%s",str);
        }
        else{
            printf("\n");
        }
    }
    else if(strcmp(ser,"-n")==0)
    {
        if(str!=NULL)
        {
            printf("%s\n",str);
        }
        else{
            printf("\n");
        }
    }
    else if(ser==NULL)
    {
        printf("\n");
    }
    else{
        if(str!=NULL)
        {
            printf("%s",ser);
        }
        else{
            printf("%s",ser);
        }
        
    }
}