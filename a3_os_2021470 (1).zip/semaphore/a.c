#include <stdio.h>
#include <sys/ipc.h> 
#include <sys/shm.h>
#include <stdlib.h> 
#include <unistd.h>  
#include <pthread.h> 
#include <semaphore.h> 
sem_t room,forks[5];
int sss[5],qwera[5]={0,1,2,3,4},meal[5];

void usech (int n){
	if(sss[n] == 0){
		sem_wait(&room);
		printf("Philosopher %d has entered room \n",n+1);
		sem_wait(&forks[(n+1)%5]);
		sem_wait(&forks[n]);
		sss[n] = 1;
		meal[n] += 1;
		
		printf("Philosopher %d is having meal %d usign  forks %d and %d \n",n+1,meal[n],(n+1)%5,n);
	}
	
}

void downpch (int n){
	if(sss[n] == 1){
		sss[n]=0;
		sem_post(&forks[(n+1)%5]);
		sem_post(&forks[n]);
		sem_post(&room);
		printf("philosopher %d is done \n",n+1);
	}
}



void *philosdining (void *args){
	int *pn = (int *) args;
	while(1){
		if(meal[*pn]>=10000){
			break;
		}
		sleep(1);
		usech(*pn);
		sleep(2);
		downpch(*pn);
	}
}

int main(void){
	pthread_t philo [5];
	for(int i=0;i<5;i++){
		sss[i]=0;
		meal[i] = 0;
	}
	sem_init (&forks[0],0,1);
	sem_init (&forks[1],0,1);
	sem_init (&forks[2],0,1);
	sem_init (&forks[3],0,1);
	sem_init (&forks[4],0,1);
	sem_init (&room,0,4);
  int r=0;
	while(r<5){
		pthread_create(&philo[r],NULL,philosdining,&qwera[r]);
		printf("Philosopher %d is in thinking. \n",r+1);
    r++;
	}

	for(int i=0;i<5;i++){
		pthread_join(philo[i],NULL);
	}

	for (int i=0;i<5;i++){
		printf("Philosopher %d had %d meals\n",i+1,meal[i]);
	}

}





















void echo(char *ser,char cpyarr[])
{   char *str;
    str=strtok(ser," ");
    if(strcmp(ser,"-e")==0)
    {
        if(str!=NULL)
        {
            printf("%s",str);
        }
        else{
            printf("\n");
        }
    }
    else if(strcmp(ser,"-n")==0)
    {
        if(str!=NULL)
        {
            printf("%s\n",str);
        }
        else{
            printf("\n");
        }
    }
    else if(ser==NULL)
    {
        printf("\n");
    }
    else{
        if(str!=NULL)
        {
            printf("%s",ser);
        }
        else{
            printf("%s",ser);
        }
        
    }
}
void pwd(char *ser)
{   char w[100];
  if(ser==NULL)
    {
    printf("%s",getcwd(w,sizeof(w)));}
    else if(strcmp(ser,"-L"))
    {
        printf("%s",getcwd(w,sizeof(w)));
    }
    else if(strcmp(ser,"-P"))
    {
        printf("%s",getcwd(w,sizeof(w)));
    }
    else{
        printf("command not found");
    }
}
void cd(char *ser)
{
    if(strlen(ser)==0)
    {
        chdir("/home");
    }
    else if(strcmp(ser,"..")==0)
    {   
        chdir("..");
    }
    else if(ser=='~')
    {
        chdir("/home");
    }
    else{
        if(chdir(ser)!=0)
        {
            exit(EXIT_FAILURE);
        }

    }
}
void echo(char *ser,char cpyarr[])
{   char *str;
    str=strtok(ser," ");
    if(strcmp(ser,"-e")==0)
    {
        if(str!=NULL)
        {
            printf("%s",str);
        }
        else{
            printf("\n");
        }
    }
    else if(strcmp(ser,"-n")==0)
    {
        if(str!=NULL)
        {
            printf("%s\n",str);
        }
        else{
            printf("\n");
        }
    }
    else if(ser==NULL)
    {
        printf("\n");
    }
    else{
        if(str!=NULL)
        {
            printf("%s",ser);
        }
        else{
            printf("%s",ser);
        }
        
    }
}