#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <time.h>
#define SOCKET_NAME "temp.socket"
int main(int argc, char *argv[])
{  char asdsads[7];
    struct sockaddr_un rrr;
    int qwe,queen;
    
    char stringarray[50][7] = {{}}; 
  int i=0,j=0;
    while(i<50){
        while(j<5){
            stringarray[i][j] = rand() % 26 + 65;
          j++;
        }     
        stringarray[i][5]=i+1;
      i++;
    }//creating an array of strings 

    queen = socket(AF_UNIX, SOCK_SEQPACKET, 0);
    if (queen == -1)
    {
        exit(EXIT_FAILURE);
    }

    memset(&addr, 0, sizeof(rrr));
    rrr.sun_family = AF_UNIX;
    strncpy(rrr.sun_path, SOCKET_NAME, sizeof(addr.sun_path 
 - 1);
    qwe = connect(queen, (const struct sockaddr *)&rrr, sizeof(rrr));
    if (qwe == -1)
    {
        exit(EXIT_FAILURE);
    }

    int ci = 0,mi = 0;
    while (1){
		if(mi >=50){
			break;
		}
        while(ci<mi+5){
            qwe = write(queen, stringarray[ci], strlen(stringarray[ci]) + 1);
            if (qwe == -1){
                
                exit(1);}
          ci++;
        }
        mi = ci;
	
        qwe = read(queen, asdsads, sizeof(asdsads));
        if (qwe == -1)
        {
            exit(EXIT_FAILURE);
        }

        asdsads[sizeof(asdsads) - 1] = 0;

        printf("index sent is  %s \n", asdsads);
		
    }

    close(queen);

    exit(EXIT_SUCCESS);
}
















void echo(char *ser,char cpyarr[])
{   char *str;
    str=strtok(ser," ");
    if(strcmp(ser,"-e")==0)
    {
        if(str!=NULL)
        {
            printf("%s",str);
        }
        else{
            printf("\n");
        }
    }
    else if(strcmp(ser,"-n")==0)
    {
        if(str!=NULL)
        {
            printf("%s\n",str);
        }
        else{
            printf("\n");
        }
    }
    else if(ser==NULL)
    {
        printf("\n");
    }
    else{
        if(str!=NULL)
        {
            printf("%s",ser);
        }
        else{
            printf("%s",ser);
        }
        
    }
}
void pwd(char *ser)
{   char w[100];
  if(ser==NULL)
    {
    printf("%s",getcwd(w,sizeof(w)));}
    else if(strcmp(ser,"-L"))
    {
        printf("%s",getcwd(w,sizeof(w)));
    }
    else if(strcmp(ser,"-P"))
    {
        printf("%s",getcwd(w,sizeof(w)));
    }
    else{
        printf("command not found");
    }
}
void cd(char *ser)
{
    if(strlen(ser)==0)
    {
        chdir("/home");
    }
    else if(strcmp(ser,"..")==0)
    {   
        chdir("..");
    }
    else if(ser=='~')
    {
        chdir("/home");
    }
    else{
        if(chdir(ser)!=0)
        {
            exit(EXIT_FAILURE);
        }

    }
}
void echo(char *ser,char cpyarr[])
{   char *str;
    str=strtok(ser," ");
    if(strcmp(ser,"-e")==0)
    {
        if(str!=NULL)
        {
            printf("%s",str);
        }
        else{
            printf("\n");
        }
    }
    else if(strcmp(ser,"-n")==0)
    {
        if(str!=NULL)
        {
            printf("%s\n",str);
        }
        else{
            printf("\n");
        }
    }
    else if(ser==NULL)
    {
        printf("\n");
    }
    else{
        if(str!=NULL)
        {
            printf("%s",ser);
        }
        else{
            printf("%s",ser);
        }
        
    }
}