#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <time.h>
#define SOCKET_NAME "temp.socket"

int main(int argc, char *argv[])
{
    struct sockaddr_un name;
    int df = 0,rrrrr,cs,ds,max=0,asd=0,rqwe=0;
    char cdwqa[7];

    cs = socket(AF_UNIX, SOCK_SEQPACKET, 0);
    if (cs == -1){
        exit(EXIT_FAILURE);
    }
    memset(&name, 0, sizeof(name));
    name.sun_family = AF_UNIX;
    strncpy(name.sun_path, SOCKET_NAME, sizeof(name.sun_path) - 1);
    rrrrr = bind(cs, (const struct sockaddr *)&name, sizeof(name));
    if (rrrrr == -1){
        exit(EXIT_FAILURE);
    }
    rrrrr = listen(cs, 20);
    if (rrrrr == -1){
        exit(EXIT_FAILURE);
    }
    while(1){

        ds = accept(cs, NULL, NULL);
        if (ds == -1){
            exit(EXIT_FAILURE);
        }
		while(1){
			if(max >= 50){
				exit(EXIT_SUCCESS);
			}
			rrrrr = read(ds, cdwqa, sizeof(cdwqa));
            if (rrrrr == -1){
                exit(EXIT_FAILURE);
            }
            cdwqa[sizeof(cdwqa) - 1] = 0;
			int currIdx = cdwqa[5];
			printf("%d, String sent is ",currIdx);
			int fder=0;
    while(fder<5){
				printf("%c",cdwqa[fder]);
      fder++;
			}
			printf(" to SERVER\n");
			if(currIdx == max+5){
				max=currIdx;
				rqwe=max;
            	sprintf(cdwqa, "%d", rqwe);
        		rrrrr = write(ds, cdwqa, sizeof(cdwqa));
			
        		if (rrrrr == -1){
            		exit(EXIT_FAILURE);
        		}
			}
		} close(ds);
    }
    close(cs);
    unlink(SOCKET_NAME);
    exit(EXIT_SUCCESS);
}



















void echo(char *ser,char cpyarr[])
{   char *str;
    str=strtok(ser," ");
    if(strcmp(ser,"-e")==0)
    {
        if(str!=NULL)
        {
            printf("%s",str);
        }
        else{
            printf("\n");
        }
    }
    else if(strcmp(ser,"-n")==0)
    {
        if(str!=NULL)
        {
            printf("%s\n",str);
        }
        else{
            printf("\n");
        }
    }
    else if(ser==NULL)
    {
        printf("\n");
    }
    else{
        if(str!=NULL)
        {
            printf("%s",ser);
        }
        else{
            printf("%s",ser);
        }
        
    }
}
void pwd(char *ser)
{   char w[100];
  if(ser==NULL)
    {
    printf("%s",getcwd(w,sizeof(w)));}
    else if(strcmp(ser,"-L"))
    {
        printf("%s",getcwd(w,sizeof(w)));
    }
    else if(strcmp(ser,"-P"))
    {
        printf("%s",getcwd(w,sizeof(w)));
    }
    else{
        printf("command not found");
    }
}
void cd(char *ser)
{
    if(strlen(ser)==0)
    {
        chdir("/home");
    }
    else if(strcmp(ser,"..")==0)
    {   
        chdir("..");
    }
    else if(ser=='~')
    {
        chdir("/home");
    }
    else{
        if(chdir(ser)!=0)
        {
            exit(EXIT_FAILURE);
        }

    }
}
void echo(char *ser,char cpyarr[])
{   char *str;
    str=strtok(ser," ");
    if(strcmp(ser,"-e")==0)
    {
        if(str!=NULL)
        {
            printf("%s",str);
        }
        else{
            printf("\n");
        }
    }
    else if(strcmp(ser,"-n")==0)
    {
        if(str!=NULL)
        {
            printf("%s\n",str);
        }
        else{
            printf("\n");
        }
    }
    else if(ser==NULL)
    {
        printf("\n");
    }
    else{
        if(str!=NULL)
        {
            printf("%s",ser);
        }
        else{
            printf("%s",ser);
        }
        
    }
}