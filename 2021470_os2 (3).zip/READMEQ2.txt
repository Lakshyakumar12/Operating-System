
we will add the system call in syscall table which is present in arch/x86/entry/syscalls/syscall_64.tbl


 451	kernel_2d_memcpy	sys_kernel_2d_memcpy 
we will edit the sys.c file in kernel/sys.c


we will implement our system call kernel_2D_memcpy

SYSCALL_DEFINE4(kernel_2D_memcpy, float * , q1 ,float * , q2 , int , r, int , c)
z
then we will build and compile the new kernel 



make -j2 // it will compile the kernel with new syscall
make modules_install
cp arch/x86_64/boot/bzImage /boot/vmlinuz-linux_lakshya
#this will create the preset using the old kernel 
sed s/linux/linux_lakshya/g \
    </etc/mkinitcpio.d/linux.preset \
    >/etc/mkinitcpio.d/linux_lakshya.preset
mkinitcpio -p linux_lakshya
grub-mkconfig -o /boot/grub/grub.cfg


After that we will reboot our system and boot into the new kernel

we will compile our test code with system call kernel_2d_memcpy which copies 2-d floating matrix by using copy_from_user and copy_to_user.

