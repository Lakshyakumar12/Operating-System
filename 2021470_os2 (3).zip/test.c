#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/syscall.h>
#define sys_kernel_2D_memcpy 451
int main()
{
    int m1[3][3]={{1,2,2},{2,3,4},{3,4,5}};
    int m2[3][3]={{1,1,1},{1,1,1},{1,1,1}};
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            printf("%d",m1[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            printf("%d",m2[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    int r=syscall(sys_kernel_2D_memcpy,m1,m2,3,3);
    if(r<0)
    {
        printf("Error");
        exit(0);
    }
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            printf("%d",m1[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            printf("%d",m2[i][j]);
        }
        printf("\n");
    }
    

    return 0;
}